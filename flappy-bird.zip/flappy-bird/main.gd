extends Node2D

const GAP = 180 # 管道上下随机波动范围
# 背景滚动速度：
const SKY_SPEED := Vector2(-30, 0)
const GROUND_SPEED := Vector2(-150, 0)

# 预加载管道蓝图，用于实例化Pipes场景。
var pipes_scene: PackedScene = preload("res://pipes.tscn")

# 定义节点引用变量
@onready var timer: Timer = $Timer
@onready var spawn: Marker2D = $SpawnPoint
@onready var bird: CharacterBody2D = $Bird
@onready var ce: Area2D = $Ceil
@onready var fl: Area2D = $Floor
@onready var pipes_group: Node2D = $PipesGroup
@onready var hud: CanvasLayer = $HUD

func _ready():
	# 建立全局信号连接
	GameManager.GameOver.connect(game_over)
	GameManager.GameStart.connect(game_start)
	# 监听边界碰撞与定时器触发
	ce.body_entered.connect(border_enter)
	fl.body_entered.connect(border_enter)
	timer.timeout.connect(cnt_times)
	
	hud.ready_start_requested.connect(_start_playing)
	hud.restart_requested.connect(_enter_ready)
	_enter_ready()                  # 启动即进入 READY


func _enter_ready():
	reset_game() # 重置游戏
	bird.is_dead = true
	bird.base_y = bird.position.y
	GameManager.state = GameManager.State.READY
	hud.show_ready()

func _start_playing():
	GameManager.GameStart.emit()    # 触发 game_start：生成管道 + 计时器
	hud.show_playing()
	bird.flap()                     # 首拍显式扇翅（bird 内跳过同帧轮询）

func game_start():
	
	new_pipes() # 立即生成第一组管道
	timer.start() # 启动定时器

func game_over():
	timer.stop() # 停止定时器
	$Sky.autoscroll = Vector2.ZERO       # 结算时背景静止
	$Ground.autoscroll = Vector2.ZERO
	await get_tree().create_timer(1.0).timeout   # 等鸟落地
	GameManager.state = GameManager.State.GAMEOVER
	hud.show_result(GameManager.last_score, GameManager.max_score, GameManager.is_new_record)
	
func cnt_times():
	new_pipes() # 记时生成新管道

func border_enter(body):
	# 检测进入边界的是否是角色，触发游戏结束信号。
	if body.is_in_group("bird") and not body.is_dead:
		GameManager.GameOver.emit()

func new_pipes():
	# 创建管道实例
	var pipes = pipes_scene.instantiate()
	# 计算随机高度
	var pos_y = randf_range(spawn.position.y - GAP, spawn.position.y + GAP)
	# 设定坐标
	pipes.global_position.x = spawn.position.x
	pipes.global_position.y = pos_y
	# 放入组
	pipes_group.add_child(pipes)


func reset_game():
	bird.global_position = Vector2(160,300) # 归位角色
	# 清空所有已存入的管道
	var pipes = pipes_group.get_children()
	for pipe in pipes:
		pipe.queue_free()
	bird.velocity = Vector2.ZERO #速度清零
	bird.rotation_degrees = 0 #角度清零
	bird.get_node("AnimatedSprite2D").play()   
	$Sky.autoscroll = SKY_SPEED        # 恢复天空滚动
	$Ground.autoscroll = GROUND_SPEED  # 恢复地面滚动
