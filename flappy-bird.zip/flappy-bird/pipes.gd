extends Node2D

const SPEED = -150    # 管道移动速度
var passed = false    # 标记

@onready var coin: Area2D = $Coin
@onready var pipe_down: Area2D = $PipeDown
@onready var pipe_up: Area2D = $PipeUp
@onready var visible_on_screen_notifier_2d: VisibleOnScreenNotifier2D = $VisibleOnScreenNotifier2D

func _ready():
	# 当角色进入上/下障碍的区域时触发
	pipe_down.body_entered.connect(pipe_entered)
	pipe_up.body_entered.connect(pipe_entered)
	
	# 当角色进入得分区域时触发
	coin.body_entered.connect(coin_entered)

	# 当整组管道完全离开屏幕时触发
	visible_on_screen_notifier_2d.screen_exited.connect(on_exited)
	
func pipe_entered(body):
	# 检查碰撞体是否属于 "bird" 分组，且角色当前还活着
	if body.is_in_group("bird") and not body.is_dead:
		GameManager.GameOver.emit() 

func on_exited():
	queue_free() # 将管道从场景移除
	
func _process(delta):
	if GameManager.state != GameManager.State.PLAYING: # 死亡/结算/READY 时冻结，画面保留
		return
	# 根据速度和帧率间隔移动位置
	position.x += delta * SPEED

func coin_entered(body):
	if GameManager.state != GameManager.State.PLAYING:
		return
	if body.is_in_group("bird") and not passed:
		passed = true
		GameManager.UpdateScore.emit()
