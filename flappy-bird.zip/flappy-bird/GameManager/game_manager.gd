extends Node

# 定义三种全局信号
signal GameStart    # 游戏开始
signal GameOver     # 游戏结束
signal UpdateScore  # 分数变动

# 游戏状态：准备 / 游玩中 / 死亡 / 游戏结束
enum State { READY, PLAYING, DEAD, GAMEOVER }
var state: State = State.READY # 当前游戏状态，初始为准备状态

var score = 0       # 全局分数变量
var last_score = 0  # 上局分数
var max_score = 0   # 最佳分数
var is_running := false
var is_new_record := false

const SAVE_PATH := "user://flappy_save.cfg"

func _ready():
	# 监听信号连接到响应函数，用于处理数据层面的更新
	UpdateScore.connect(add_score)
	GameOver.connect(game_over)
	GameStart.connect(game_start)
	load_best()

func add_score():
	if state != State.PLAYING:      # 只有游玩中才计分
		return
	score += 1

func game_start():
	is_running = true
	score = 0          # 开局清零分数
	state = State.PLAYING
	
func game_over():
	if state == State.DEAD or state == State.GAMEOVER:
		return 
	is_running = false
	last_score = score  
	if last_score > max_score:
		max_score = last_score
		save_best()
	state = State.DEAD
	
func load_best():
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) == OK:
		max_score = int(cfg.get_value("score", "best", 0))

func save_best():
	var cfg := ConfigFile.new()
	cfg.set_value("score", "best", max_score)
	cfg.save(SAVE_PATH)
	
