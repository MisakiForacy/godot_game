# 文件：res://ready_panel.gd（新建，挂在 ReadyPanel 上）
extends Control

signal start_requested

@onready var ready_text: TextureRect = $ReadyText
@onready var hint: TextureRect = $Hint

var _busy := false
var _hand_y := 0.0
var _hand_tween: Tween

func _ready() -> void:
	visible = false
	_hand_y = hint.position.y

func reset() -> void:
	_busy = false
	visible = true
	if _hand_tween: _hand_tween.kill()

	ready_text.modulate.a = 0.0
	var t := create_tween()
	t.tween_property(ready_text, "modulate:a", 1.0, 0.2)

	hint.position.y = _hand_y
	_hand_tween = create_tween().set_loops()
	_hand_tween.tween_property(hint, "position:y", _hand_y - 10.0, 0.6).set_trans(Tween.TRANS_SINE)
	_hand_tween.tween_property(hint, "position:y", _hand_y, 0.6).set_trans(Tween.TRANS_SINE)

func hide_overlay() -> void:
	visible = false
	if _hand_tween: _hand_tween.kill()

func _unhandled_input(event: InputEvent) -> void:
	if not visible or _busy:
		return
	var tapped := event.is_action_pressed("fly") or event.is_action_pressed("ui_accept")
	if event is InputEventScreenTouch and event.pressed:
		tapped = true
	if tapped:
		_busy = true
		get_viewport().set_input_as_handled()
		start_requested.emit()
