extends CanvasLayer

signal ready_start_requested     # READY 页被点击
signal restart_requested         # 结算页点 OK

#const TEXT_READY = preload("res://images/text_ready.png")
#const TEXT_GAME_OVER = preload("res://images/text_game_over.png")


# 定义节点引用变量
@onready var score_root: Control = $Score
@onready var score_label = $Score/ScoreLabel
@onready var ready_panel: Control = $ReadyPanel
@onready var result_panel: Control = $ResultPanel
@onready var hint = $ReadyPanel/Hint

func _ready() -> void:
	GameManager.UpdateScore.connect(update_score)
	ready_panel.start_requested.connect(func() -> void: ready_start_requested.emit())
	result_panel.restart_requested.connect(func() -> void: restart_requested.emit())
	update_score()

func update_score() -> void:
	score_label.text = "Score: %d" % GameManager.score

func show_ready() -> void:
	visible = true
	score_root.hide()
	result_panel.hide()
	ready_panel.reset()

func show_playing() -> void:
	visible = true
	ready_panel.hide_overlay()
	result_panel.hide()
	score_root.show()
	update_score()

func show_result(score: int, best: int, is_new: bool) -> void:
	visible = true
	score_root.hide()
	ready_panel.hide_overlay()
	result_panel.show_result(score, best, is_new)
#
#func _ready():
	## 初始化显示
	#update_score() 
	## 信号连接
	#GameManager.GameOver.connect(game_over)
	#GameManager.UpdateScore.connect(update_score)
	#GameManager.GameStart.connect(game_start)
	#
#
#func update_score():
	## 从全局变量中读取最新的分数，并修改文本显示
	#score_label.text = "Score: %s" %str(GameManager.score)
	#
#func game_start():
	#update_score()
	## 隐藏Message和hint两个元素
	#message.hide()
	#hint.hide()
	#
#func game_over():
	#update_score()
	#message.texture = TEXT_GAME_OVER
	#message.show()
	#
#func on_pressed():
	## 游戏开始
	#GameManager.GameStart.emit() 
	
