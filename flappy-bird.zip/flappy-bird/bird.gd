extends CharacterBody2D

const SPEED = 300.0
const JUMP_VELOCITY = -400.0  # 向上飞行的瞬时速度
const GRAVITY = 1200          # 模拟重力加速度
const GROUND= 720             #地面告诉

# 预加载音效资源
const HIT = preload("res://audio/hit.ogg")
const POINT = preload("res://audio/point.ogg")
const WING = preload("res://audio/wing.ogg")

var degree = 0            # 用于记录当前的旋转角度
var is_dead = true            # 死亡状态标识，默认死亡（等待游戏正式开始）
var base_y = 300         # 待机浮动的基准Y坐标
var ready_t = 0          # 待机状态计时器

@export var max_speed := 700  # 最大下落速度限制
@onready var animated_sprite_2d = $AnimatedSprite2D
@onready var fly_sound: AudioStreamPlayer = $FlySound
@onready var score_sound: AudioStreamPlayer = $ScoreSound

func _ready():
	# 连接三种全局信号
	GameManager.GameOver.connect(game_over)
	GameManager.UpdateScore.connect(get_score)
	GameManager.GameStart.connect(game_start)
	

func enter_dead() -> void:
	is_dead = true  
	animated_sprite_2d.stop()     # 停止小鸟默认动画
	animated_sprite_2d.frame = 0  # 重置动画到第0帧
	velocity.y = -250.0           # 碰撞后先小反弹，再自由落体
	
func game_start():
	is_dead = false   
	#animated_sprite_2d.play()   # 每次开始都恢复扇翅动画          

func get_score():
	score_sound.stream = POINT   # 得分音效
	score_sound.play()           

func game_over():
	fly_sound.stream = HIT       # 撞击声
	fly_sound.play()
	enter_dead()
	
func flap():
	velocity.y = JUMP_VELOCITY
	fly_sound.stream = WING
	fly_sound.play()

func _physics_process(delta: float) -> void:
	# GameManager状态机分支
	match GameManager.state:
		GameManager.State.READY:
			# 待机：正弦浮动，不启用重力
			ready_t += delta
			position.y = base_y + sin(ready_t * 3.0) * 8.0
			return

		GameManager.State.DEAD:
			# 死亡：下落+慢慢低头旋转，碰到地面卡住
			velocity.y += GRAVITY * delta
			position += velocity * delta
			rotation_degrees = move_toward(rotation_degrees, 90.0, 300.0 * delta)
			if position.y >= GROUND - 12.0:
				position.y = GROUND - 12.0
				velocity = Vector2.ZERO
			return

		GameManager.State.PLAYING:
			# 1. 应用重力：速度 = 加速度 * 时间
			velocity.y += GRAVITY * delta

			# 2. 处理玩家输入：检测到名为 "fly" 的动作按下
			if Input.is_action_just_pressed("fly"):
				flap()

			# 3. 计算旋转角度：根据当前纵向速度改变仰俯角
			# 使用 clampf 将旋转限制在 -20° 到 20° 之间，避免“翻车”
			degree = clampf(-20 * velocity.y / JUMP_VELOCITY, -20, 20)
			rotation_degrees = degree

			# 4. 速度限制：确保下落速度不会无限增加
			velocity.y = clampf(velocity.y, -max_speed, max_speed)

			# 5. 执行移动：根据 velocity 自动处理碰撞与滑动
			move_and_slide()
			return
