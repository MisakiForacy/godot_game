# 文件：res://result_panel.gd（新建，挂在 ResultPanel 上）
extends Control

signal restart_requested

const MEDALS := preload("res://images/medals.png")
const THRESHOLDS := [10, 20, 50, 100]   # 铜 / 银 / 金 / 白金

@onready var game_over_text: TextureRect = $GameOverText
@onready var panel: TextureRect = $Panel
@onready var medal: TextureRect = $Panel/Medal
@onready var score_value: Label = $Panel/ScoreValue
@onready var best_value: Label = $Panel/BestValue
@onready var new_badge: TextureRect = $Panel/NewBadge
@onready var button: TextureButton = $Button

var _locked := true       # 出现后 0.45s 内不可点，防误触

func _ready() -> void:
	visible = false
	button.pressed.connect(_on_ok)

func show_result(score: int, best: int, is_new: bool) -> void:
	visible = true
	_locked = true
	score_value.text = str(score)
	best_value.text = str(best)
	new_badge.visible = is_new
	_apply_medal(score)

	game_over_text.modulate.a = 0.0
	panel.scale = Vector2(0.85, 0.85)
	panel.pivot_offset = panel.size * 0.5
	button.modulate.a = 0.0

	var t := create_tween().set_parallel(true)
	t.tween_property(game_over_text, "modulate:a", 1.0, 0.18)
	t.tween_property(panel, "scale", Vector2.ONE, 0.22) \
		.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	t.tween_property(button, "modulate:a", 1.0, 0.18).set_delay(0.25)

	await get_tree().create_timer(0.45).timeout
	_locked = false

func _on_ok() -> void:
	if _locked:
		return
	_locked = true
	visible = false
	restart_requested.emit()

func _apply_medal(score: int) -> void:
	var idx := -1
	for i in range(THRESHOLDS.size()):
		if score >= THRESHOLDS[i]:
			idx = i
	if idx < 0:
		medal.hide()
		return
	medal.show()
	var at := AtlasTexture.new()
	at.atlas = MEDALS
	at.region = Rect2(idx * 44, 0, 44, 44)
	medal.texture = at
